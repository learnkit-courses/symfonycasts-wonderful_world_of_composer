The Wonderful World of Composer
===============================

Hi there! Enclosed (in the finished directory) is the end-product
of the "Wonderful World of Composer" screencast!

The code is a fully-functional Drupal 7 project, but here's the
important things to focus on:

* composer.phar
* composer.json
* composer.lock
* vendor/*
* sites/all/modules/list_files/list_files.module (the get_current_files function) 
* sites/default/settings.php (the require statement on line 528)

Ok, have fun!
